#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
source scripts/environment.sh
exec /usr/bin/python3 scripts/start_lab.py --demo
