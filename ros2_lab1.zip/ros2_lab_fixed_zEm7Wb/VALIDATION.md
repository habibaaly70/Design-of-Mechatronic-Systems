# Current revision checks

This revision permanently tightens position/yaw tolerances to 0.005 / 0.002,
removes the two reported legacy build-warning triggers, and adds OS process leases,
a shared project ROS domain (86), graph preflight, and a single-terminal starter.

All 13 offline tests passed, including duplicate process-lock refusal, restart and
OS cleanup, and square edge precision at three side lengths. Static checks passed. The real starter was also exercised with substitute child
processes (not ROS): duplicate refusal, SIGHUP/SIGTERM child cleanup and restart passed.
The 21 original evidence/bag files are preserved byte for byte.
ROS is unavailable in this preparation environment. This revision has NOT been
built/run on Lyrical here. Run START_LAB.sh and the real integration checks locally.

Earlier revision notes and the supplied historical report follow:

---

# Lyrical adaptation status

This project now targets Ubuntu 26.04 and ROS 2 Lyrical. The runtime imports and
package dependencies use turtlesim_msgs. Setup/run scripts and the current README
also target Lyrical. The 8 ROS-independent controller tests were rerun successfully
following this adaptation; Python, XML, JSON and shell syntax checks also passed.

The current preparation environment has no ROS installation. The adapted code has
NOT been built or runtime-tested under Lyrical here. Run the supplied build and
runtime-check scripts on your laptop. No new Lyrical bag or GUI screenshot was
created. Existing square_demo/ and evidence/ are retained unchanged from the
uploaded Jazzy project; they document the earlier run, not a new Lyrical run.
The replay checker now saves new results to evidence/lyrical_replay_trajectory.json.

The original validation report from the supplied project follows. Its claims are
historical evidence supplied with that project, not tests rerun during this adaptation.

---

# Actual ROS 2 validation report

Date: 25 October 2026. Environment: Ubuntu 24.04, ROS 2 Jazzy, system Python 3.12.

## Build and tests

- Both source packages built successfully in a fresh workspace using colcon.
- 8 controller unit tests passed, including 100 deterministic randomized pose cases.
- 9 real integration test groups passed against the actual Turtlesim executable:
  1. Reset repeated; start position and yaw confirmed.
  2. YAML speed parameters applied by launch.
  3. Custom speed service, atomic rejection and direct parameter updates.
  4. Four movement directions, final yaw, action feedback/results.
  5. Invalid out-of-window target rejection.
  6. Live speed limits, concurrent motion/reset rejection and pose cancellation.
  7. Square repeated twice, four ordered sides and final pose.
  8. Concurrent square rejection, cancellation propagated and reset afterward.
  9. Oversized square rejection.
- The two successful integration squares each caused exactly four GoToPose calls; the separately recorded square also caused exactly four (see launch log).

## Real recording and replay

- Storage: SQLite3; file: square_demo/square_demo_0.db3.
- Duration: 21.264975411 seconds.
- Messages: 1,883 = 553 velocity commands + 1,330 poses.
- The recorded final command is zero linear and angular velocity.
- All recorded command speeds remain within 1.5 linear and 2.0 angular limits.
- Original final pose: (5.54481459, 5.57176161, -0.01583545).
- Original final position error from reset position: about 0.02732 units.
- Playback was run against live Turtlesim after reset, publishing only cmd_vel.
- A second playback was independently sampled: 1,295 live pose samples; every requested corner approached within 0.093 units; final position error 0.09813 units and final yaw 0.01351 radians.
- `trajectory_comparison.png` is a plot of actual ROS pose data, not a screenshot or synthetic animation.
- Playback is open-loop; timing-dependent differences are expected. It is not an exact closed-loop path reproduction.

## Evidence and limits

Build/test logs, bag metadata, measured trajectories and summary metrics are included under evidence/. `runtime_check.py` and `check_bag_replay.py` reproduce the tests on a running system. The simulator ran with QT_QPA_PLATFORM=offscreen because this environment blocks GUI display sockets. Therefore visible pen rendering was not inspected; reset service sequence and pose behavior were exercised. Network-interface-enumeration warnings appear in logs due to sandbox restrictions, but the real topic/action/service communications succeeded.

Humble and other ROS distributions were not runtime-tested. No GitHub upload or form submission was performed. Team details remain placeholders. Bonus marks are subject to the instructor's evaluation of the included Strategy explanation and real bag evidence.
