import threading
import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer, ActionClient, GoalResponse, CancelResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from action_msgs.msg import GoalStatus
from std_srvs.srv import Trigger
from turtle_interfaces.action import DrawSquare, GoToPose
from .controller import square_corners
from .common import run, wait_future

class SquareServer(Node):
    def __init__(self):
        super().__init__('square_server')
        self.group = ReentrantCallbackGroup()
        self.lock = threading.Lock()
        self.reset_client = self.create_client(Trigger, '/reset_turtle', callback_group=self.group)
        self.move_client = ActionClient(self, GoToPose, '/go_to_pose', callback_group=self.group)
        self.server = ActionServer(self, DrawSquare, '/draw_square', self.execute,
            goal_callback=self.goal, cancel_callback=lambda _: CancelResponse.ACCEPT,
            callback_group=self.group)

    def goal(self, request):
        try:
            square_corners(request.side_length)
        except ValueError:
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT if self.lock.acquire(blocking=False) else GoalResponse.REJECT

    def execute(self, handle):
        result = DrawSquare.Result()
        child = None
        pending_child = None
        try:
            if not self.reset_client.wait_for_service(timeout_sec=10.0):
                raise TimeoutError('Reset service unavailable')
            if not self.move_client.wait_for_server(timeout_sec=10.0):
                raise TimeoutError('goToPose server unavailable')
            reset = wait_future(self.reset_client.call_async(Trigger.Request()), 30.0)
            if not reset.success:
                raise RuntimeError(reset.message)
            for side, target in enumerate(square_corners(handle.request.side_length), 1):
                if handle.is_cancel_requested:
                    handle.canceled()
                    result.message = 'Square canceled'
                    return result
                feedback = DrawSquare.Feedback()
                feedback.side, feedback.status = side, f'Drawing side {side}/4'
                handle.publish_feedback(feedback)
                goal = GoToPose.Goal()
                goal.target.x, goal.target.y, goal.target.yaw = target
                pending_child = self.move_client.send_goal_async(goal)
                child = wait_future(pending_child, 10.0)
                pending_child = None
                if not child.accepted:
                    raise RuntimeError(f'goToPose rejected side {side}; another goal may be active')
                future = child.get_result_async()
                deadline = time.monotonic()+310.0
                while rclpy.ok() and not future.done():
                    if handle.is_cancel_requested:
                        wait_future(child.cancel_goal_async(), 10.0)
                        wait_future(future, 10.0)
                        child = None
                        handle.canceled()
                        result.message = 'Square canceled; active motion stopped'
                        return result
                    if time.monotonic() > deadline:
                        raise TimeoutError('Side timed out')
                    time.sleep(0.02)
                wrapped = wait_future(future)
                child = None
                if wrapped.status != GoalStatus.STATUS_SUCCEEDED or not wrapped.result.success:
                    raise RuntimeError(f'Side {side} failed: {wrapped.result.message}')
            if handle.is_cancel_requested:
                handle.canceled()
                result.message = 'Canceled at completion'
            else:
                handle.succeed()
                result.success, result.message = True, 'Square completed with exactly 4 goToPose calls'
            return result
        except Exception as exc:
            result.message = str(exc)
            self.get_logger().error(str(exc))
            if child is not None and child.accepted and rclpy.ok():
                try:
                    wait_future(child.cancel_goal_async())
                except Exception:
                    pass
            if pending_child is not None:
                # If acceptance arrives after timeout, cancel that late goal too.
                def cancel_late(future):
                    try:
                        late = future.result()
                        if late.accepted:
                            late.cancel_goal_async()
                    except Exception:
                        pass
                pending_child.add_done_callback(cancel_late)
            if handle.is_active:
                handle.abort()
            return result
        finally:
            self.lock.release()

def main(args=None):
    run(SquareServer, args)
