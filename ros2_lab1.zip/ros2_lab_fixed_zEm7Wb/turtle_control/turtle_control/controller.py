"""ROS-independent rotate/drive/final-align strategy with explicit states."""
import math
from enum import Enum

START = (5.544445, 5.544445, 0.0)
POSITION_TOL = 0.005
ANGLE_TOL = 0.002

class Phase(Enum):
    ALIGN = 'align'
    DRIVE = 'drive'
    FINAL = 'final_yaw'
    DONE = 'done'

def wrap(angle):
    return math.atan2(math.sin(angle), math.cos(angle))

def clamp(value, limit):
    return max(-limit, min(limit, value))

def valid_target(target):
    x, y, yaw = target
    return all(math.isfinite(v) for v in target) and 0.1 <= x <= 10.9 and 0.1 <= y <= 10.9

def valid_speeds(linear, angular):
    return all(math.isfinite(v) and v > 0 for v in (linear, angular))

def square_corners(side):
    if not math.isfinite(side) or not 0.1 <= side <= 5.0:
        raise ValueError('Side length must be finite and between 0.1 and 5.0.')
    x, y, _ = START
    return [(x+side, y, math.pi/2), (x+side, y+side, math.pi),
            (x, y+side, -math.pi/2), (x, y, 0.0)]

class RotateDriveStrategy:
    """Strategy: rotate in place, drive, then align final yaw. Fresh per goal."""
    def __init__(self):
        self.phase = Phase.ALIGN

    def step(self, pose, target, max_linear, max_angular):
        x, y, theta = pose
        gx, gy, yaw = target
        distance = math.hypot(gx-x, gy-y)
        heading_error = wrap(math.atan2(gy-y, gx-x)-theta)
        final_error = wrap(yaw-theta)
        if distance <= POSITION_TOL:
            self.phase = Phase.FINAL
        if self.phase == Phase.ALIGN:
            if abs(heading_error) > ANGLE_TOL:
                return 0.0, clamp(4.0*heading_error, max_angular), distance, heading_error
            self.phase = Phase.DRIVE
        if self.phase == Phase.DRIVE:
            if abs(heading_error) > 0.25:
                self.phase = Phase.ALIGN
                return 0.0, clamp(4.0*heading_error, max_angular), distance, heading_error
            return min(max_linear, 1.5*distance), clamp(4.0*heading_error, max_angular), distance, heading_error
        if abs(final_error) <= ANGLE_TOL:
            self.phase = Phase.DONE
            return 0.0, 0.0, distance, final_error
        return 0.0, clamp(4.0*final_error, max_angular), distance, final_error
