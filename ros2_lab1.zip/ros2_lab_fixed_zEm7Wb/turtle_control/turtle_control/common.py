import time
import rclpy
from rclpy.executors import MultiThreadedExecutor, ExternalShutdownException

def wait_future(future, timeout=10.0):
    # Called only on worker threads with a ReentrantCallbackGroup and >=4 threads.
    deadline = time.monotonic() + timeout
    while rclpy.ok() and not future.done():
        if time.monotonic() >= deadline:
            raise TimeoutError('ROS operation timed out')
        time.sleep(0.01)
    if not future.done():
        raise RuntimeError('ROS shutting down')
    return future.result()

def _run(node_type, args=None):
    rclpy.init(args=args)
    node = node_type()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # Stop workers before destroying their publishers and clients.
        if rclpy.ok():
            if hasattr(node, 'stop'):
                node.stop()
            rclpy.shutdown()
        executor.shutdown()
        node.destroy_node()


def run(node_type, args=None):
    # Applies even when someone bypasses START_LAB.sh and runs a node directly.
    from .session import ProcessLease, AlreadyRunning
    try:
        with ProcessLease(node_type.__name__):
            _run(node_type, args)
    except AlreadyRunning as exc:
        raise SystemExit(str(exc)) from None
