"""Linux process leases: refuse a duplicate lab launcher or server per ROS domain."""
import fcntl
import os
from pathlib import Path


class AlreadyRunning(RuntimeError):
    pass


class ProcessLease:
    def __init__(self, name, domain=None, directory=None):
        domain = str(domain if domain is not None else os.environ.get('ROS_DOMAIN_ID', '0'))
        if not domain.isdigit() or not 0 <= int(domain) <= 232:
            raise ValueError('ROS_DOMAIN_ID must be an integer from 0 to 232')
        if not name.replace('_', '').isalnum():
            raise ValueError('Invalid lease name')
        self.directory = Path(directory) if directory is not None else Path.home()/'.cache'/'ros2_lab1'/'locks'
        self.path = self.directory/f'domain_{domain}_{name}.lock'
        self.stream = None
        self.name = name
        self.domain = domain

    def __enter__(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        self.stream = self.path.open('a+')
        try:
            fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.stream.close()
            self.stream = None
            raise AlreadyRunning(
                f'{self.name} is already running on ROS domain {self.domain}. '
                'Use the existing turtle window. To restart, press Ctrl+C in its launch terminal first.') from None
        self.stream.seek(0)
        self.stream.truncate()
        self.stream.write(str(os.getpid()))
        self.stream.flush()
        return self

    def __exit__(self, *_):
        if self.stream is not None:
            fcntl.flock(self.stream.fileno(), fcntl.LOCK_UN)
            self.stream.close()
            self.stream = None
        # Leave the path in place. The OS lock, not file existence, determines ownership.
