from setuptools import setup, find_packages
from glob import glob
setup(
    name='turtle_control', version='0.1.0', packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/turtle_control']),
        ('share/turtle_control', ['package.xml']),
        ('share/turtle_control/launch', glob('launch/*.launch.py')),
        ('share/turtle_control/config', glob('config/*.yaml')),
    ],
    install_requires=['setuptools'], zip_safe=True,
    maintainer='Lab Team', maintainer_email='team@example.com',
    description='ROS 2 turtlesim lab', license='MIT', extras_require={'test': ['pytest']},
    entry_points={'console_scripts': [
        'motion_server = turtle_control.motion_server:main',
        'square_server = turtle_control.square_server:main',
    ]},
)
