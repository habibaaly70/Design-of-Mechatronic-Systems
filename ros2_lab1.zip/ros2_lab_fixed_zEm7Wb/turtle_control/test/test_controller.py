import math
import random
import unittest
from turtle_control.controller import (RotateDriveStrategy, Phase, START,
    POSITION_TOL, ANGLE_TOL, square_corners, valid_speeds, valid_target, wrap)


def simulate(start, target, change_speed=False):
    pose = list(start)
    strategy = RotateDriveStrategy()
    for i in range(30000):
        vmax, wmax = (0.4, 0.5) if change_speed and i > 30 else (1.5, 2.0)
        v, w, distance, angle = strategy.step(pose, target, vmax, wmax)
        assert 0.0 <= v <= vmax
        assert abs(w) <= wmax + 1e-12
        if strategy.phase == Phase.DONE:
            assert math.hypot(pose[0]-target[0], pose[1]-target[1]) <= POSITION_TOL
            assert abs(wrap(pose[2]-target[2])) <= ANGLE_TOL
            return pose
        dt = 0.02
        pose[0] += v*math.cos(pose[2])*dt
        pose[1] += v*math.sin(pose[2])*dt
        pose[2] = wrap(pose[2]+w*dt)
        assert 0.0 <= pose[0] <= 11.0 and 0.0 <= pose[1] <= 11.0
    raise AssertionError('Controller did not converge')

class ControllerTests(unittest.TestCase):
    def test_cardinal_and_behind(self):
        for target in [(8.,5.54,0.), (2.,5.54,math.pi), (5.54,8.,1.2), (5.54,2.,-2.0)]:
            simulate(START, target)

    def test_random_poses(self):
        rng = random.Random(9528)
        for _ in range(100):
            start = (rng.uniform(.2,10.8),rng.uniform(.2,10.8),rng.uniform(-math.pi,math.pi))
            target = (rng.uniform(.2,10.8),rng.uniform(.2,10.8),rng.uniform(-8,8))
            simulate(start,target)

    def test_square_geometry_and_repeated_runs(self):
        for side in [.1, 2., 5.]:
            corners = square_corners(side)
            self.assertEqual(len(corners), 4)
            previous = START
            for target in corners:
                self.assertAlmostEqual(math.hypot(target[0]-previous[0],target[1]-previous[1]),side)
                self.assertTrue(valid_target(target))
                previous = target
            for _ in range(2):
                pose = START
                for target in corners:
                    pose = simulate(pose,target)
                self.assertLessEqual(math.hypot(pose[0]-START[0],pose[1]-START[1]),POSITION_TOL)

    def test_live_speed_limits(self):
        simulate(START,(10.,9.,-2.8),change_speed=True)

    def test_yaw_wrap_and_same_position(self):
        simulate((5.,5.,math.pi-.01),(5.,5.,-math.pi+.1))
        self.assertAlmostEqual(wrap(3*math.pi),math.pi)

    def test_invalid_speeds(self):
        for bad in [0.,-1.,float('nan'),float('inf')]:
            self.assertFalse(valid_speeds(bad,1.))
            self.assertFalse(valid_speeds(1.,bad))
        self.assertTrue(valid_speeds(.01,2.))

    def test_invalid_targets(self):
        for t in [(-1.,5.,0.),(12.,5.,0.),(5.,float('nan'),0.),(5.,5.,float('inf'))]:
            self.assertFalse(valid_target(t))

    def test_invalid_square(self):
        for side in [0.,-.1,5.1,float('nan'),float('inf')]:
            with self.assertRaises(ValueError):
                square_corners(side)

if __name__ == '__main__':
    unittest.main()
