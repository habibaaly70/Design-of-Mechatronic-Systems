import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from turtle_control.session import ProcessLease, AlreadyRunning
from turtle_control.controller import START, RotateDriveStrategy, Phase, square_corners, wrap


class SessionTests(unittest.TestCase):
    def test_duplicate_resource_is_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            with ProcessLease('launcher',86,directory):
                with self.assertRaises(AlreadyRunning):
                    with ProcessLease('launcher',86,directory):
                        self.fail('Duplicate launcher acquired the lock')

    def test_other_domains_are_independent(self):
        with tempfile.TemporaryDirectory() as directory:
            with ProcessLease('launcher',86,directory), ProcessLease('launcher',87,directory):
                pass

    def test_release_allows_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            with ProcessLease('launcher',86,directory):
                pass
            with ProcessLease('launcher',86,directory):
                pass

    def test_process_exit_releases_lock(self):
        # Verify the actual Linux OS lock, including cleanup following a killed process.
        with tempfile.TemporaryDirectory() as directory:
            script = ("from turtle_control.session import ProcessLease; import sys,time; "
                      "lease=ProcessLease('launcher',86,sys.argv[1]); lease.__enter__(); "
                      "print('ready',flush=True); time.sleep(30)")
            process=subprocess.Popen([sys.executable,'-c',script,directory],stdout=subprocess.PIPE,text=True)
            try:
                self.assertEqual(process.stdout.readline().strip(),'ready')
                with self.assertRaises(AlreadyRunning):
                    with ProcessLease('launcher',86,directory):
                        pass
            finally:
                process.kill()
                process.wait(timeout=3)
                process.stdout.close()
            with ProcessLease('launcher',86,directory):
                pass


class SquarePrecisionTests(unittest.TestCase):
    def test_square_edges_stay_close_to_their_ideal_lines(self):
        for side in (0.8,2.0,5.0):
            pose=list(START)
            ideal_start=START
            for target in square_corners(side):
                control=RotateDriveStrategy()
                for _ in range(15000):
                    v,w,_,_=control.step(pose,target,1.5,2.0)
                    # Perpendicular distance from the intended straight square edge.
                    dx,dy=target[0]-ideal_start[0],target[1]-ideal_start[1]
                    cross=abs(dx*(pose[1]-ideal_start[1])-dy*(pose[0]-ideal_start[0]))/side
                    self.assertLessEqual(cross,0.006)
                    if control.phase==Phase.DONE:
                        break
                    dt=0.01
                    pose[0]+=v*math.cos(pose[2])*dt
                    pose[1]+=v*math.sin(pose[2])*dt
                    pose[2]=wrap(pose[2]+w*dt)
                else:
                    self.fail('Square side did not converge')
                self.assertLessEqual(math.hypot(pose[0]-target[0],pose[1]-target[1]),0.0051)
                ideal_start=target


if __name__=='__main__':
    unittest.main()
