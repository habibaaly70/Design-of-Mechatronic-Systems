# ROS 2 Lab 1 - Turtlesim, Actions and Services

Target: Ubuntu 26.04 + ROS 2 Lyrical. Alexandria University - Design of Mechatronics Systems.
Start with START_HERE.md. Nothing was uploaded to GitHub and no submission was sent.

## Team (complete before submission)

| Student | ID |
| --- | --- |
| [Name 1] | [ID 1] |
| [Name 2] | [ID 2] |
| [Name 3] | [ID 3] |

Replace generic maintainer names/emails in both package.xml files and setup.py too.

## Run with one command

Stop previous lab launches with Ctrl+C. Extract this ZIP into a fresh folder, open
the folder containing START_LAB.sh in VS Code, then open a Bash terminal there:

```bash
bash START_LAB.sh
```

This builds just the two packages, checks for existing turtle lab nodes in domain 86,
launches the system, waits for a fresh simulator pose and action readiness, then draws one square.
Leave that terminal running; Ctrl+C stops only the processes started by this runner.
For a launch without the automatic square, run `bash scripts/run.sh` instead.

To draw again, with the launch still running and idle, in a second terminal in this folder:

```bash
bash scripts/draw_square.sh
```

If prerequisites are missing, first run `bash scripts/install_dependencies.sh`.
Use the Ubuntu system Python rather than a virtualenv or Conda environment.
The scripts expect /opt/ros/lyrical/setup.bash; update scripts/environment.sh if your ROS was installed from source.

## Permanent changes in this edition

- Pose, teleport and pen imports use turtlesim_msgs and its dependency is declared.
- Position tolerance is 0.005 simulator units; angle tolerance is 0.002 rad.
  This reduces corner offsets and heading drift. It does not replace the rendered image with a perfect vector square.
- The Python package uses the supported pytest test extra instead of tests_require.
- The interface CMake minimum is 3.10, removing the reported CMake <3.10 deprecation warning.
- Helper scripts consistently choose ROS_DOMAIN_ID=86. To intentionally choose another domain,
  set TURTLE_LAB_DOMAIN_ID to the same value in every project terminal.
- A per-user, per-domain Linux OS lock refuses a second starter even from another extracted copy.
  Separate locks also refuse duplicate copies of the updated motion and square server executables.
  The locks release on process exit; leftover lock files do not block restarts.
- Discovery checks reject starting beside an older lab already present in the selected domain.
  Old programs in domain 0 or 42 are isolated from the default domain used here.
- The automatic square waits for readiness, checks known duplicate node names and checks action success.

These protections apply to the supplied runner and updated executables. Bypassing the runner with
unrelated/older code can still create conflicts. Use one simulator and one command owner at a time.
The starter refuses conflicts rather than terminating other programs.

## Packages and interfaces

| Package / file | Purpose |
| --- | --- |
| turtle_interfaces | ament_cmake interface-only package |
| msg/TargetPose.msg | float64 x, y, yaw |
| action/GoToPose.action | Custom target goal; success/message result; distance/angle/phase feedback |
| action/DrawSquare.action | side_length goal; success/message result; side/status feedback |
| srv/SetSpeedLimits.srv | Atomic linear/angular limits request; success/message response |
| turtle_control | ament_python server, motion strategy, launch/configuration and tests |
| controller.py | Rotate -> drive -> final yaw controller and square geometry |
| motion_server.py | Pose action, reset, speed parameters and speed service |
| square_server.py | Reset and exactly four sequential go_to_pose calls |
| session.py | Process leases for duplicate-run protection |
| launch/lab.launch.py | Turtlesim and both servers, with YAML parameters |

## Manual build / terminal environment

The two packages live directly in the extracted project folder. No copying into src is required.
For a manual build (stop the running launch before changing/building code):

```bash
source /opt/ros/lyrical/setup.bash
colcon build --symlink-install --base-paths turtle_interfaces turtle_control
```

For direct ROS commands, run this in each NEW Bash terminal opened in this project:

```bash
source scripts/workspace.sh
```

This sources Lyrical and the local install and sets the project's domain. The helper scripts do this automatically.
Do not build from your Home folder: colcon might discover other copies of the same packages.
Do not use VS Code Run Python File for a server; start through the supplied runner/launch.

## Demonstrate every requirement

Start once with START_LAB.sh. Wait for the automatic square to finish. In a second terminal:

```bash
source scripts/workspace.sh
ros2 node list
ros2 topic list -t
ros2 service list -t
ros2 action list -t
ros2 action info /draw_square
ros2 action info /go_to_pose
ros2 interface show turtle_interfaces/msg/TargetPose
ros2 interface show turtle_interfaces/action/GoToPose
ros2 interface show turtle_interfaces/action/DrawSquare
ros2 interface show turtle_interfaces/srv/SetSpeedLimits
```

Both actions should have exactly one server. Simulator pose is /turtle1/pose
(turtlesim_msgs/msg/Pose); velocity input is /turtle1/cmd_vel (geometry_msgs/msg/Twist).
Yaw is in radians: 0 right, pi/2 up, pi left, -pi/2 down. Position uses simulator units.

### Pose action

```bash
ros2 action send_goal /go_to_pose turtle_interfaces/action/GoToPose '{target: {x: 8.0, y: 7.0, yaw: 1.57079632679}}' --feedback
ros2 topic echo /turtle1/pose --once
```

Try different directions, waiting for each goal to finish:

```bash
ros2 action send_goal /go_to_pose turtle_interfaces/action/GoToPose '{target: {x: 2.0, y: 5.5, yaw: 3.14159265359}}' --feedback
ros2 action send_goal /go_to_pose turtle_interfaces/action/GoToPose '{target: {x: 5.5, y: 8.0, yaw: 1.57079632679}}' --feedback
ros2 action send_goal /go_to_pose turtle_interfaces/action/GoToPose '{target: {x: 5.5, y: 2.0, yaw: -1.57079632679}}' --feedback
```

Target x/y must be finite and between 0.1 and 10.9. Any finite yaw is accepted, with wrapped errors.
Goals time out after 300 seconds. Stale pose aborts motion. One motion/reset can run at a time.

### Live speed limits

```bash
ros2 param list /motion_server
ros2 param get /motion_server max_linear_speed
ros2 param get /motion_server max_angular_speed
ros2 param set /motion_server max_linear_speed 0.5
ros2 param set /motion_server max_angular_speed 0.8
ros2 service call /set_speed_limits turtle_interfaces/srv/SetSpeedLimits '{max_linear_speed: 1.0, max_angular_speed: 1.5}'
```

Limits are read on every 50 Hz controller iteration, so they change during motion.
The service changes both atomically. Use decimal doubles such as 1.0. Zero, negative, NaN and
infinite speeds are rejected by both the parameter callback and custom service.

```bash
ros2 service call /set_speed_limits turtle_interfaces/srv/SetSpeedLimits '{max_linear_speed: -1.0, max_angular_speed: 2.0}'
ros2 param set /motion_server max_angular_speed 0.0
```

These should fail and preserve the existing values. Default YAML limits are linear 1.5 and angular 2.0.

### Reset

```bash
ros2 service call /reset_turtle std_srvs/srv/Trigger '{}'
ros2 topic echo /turtle1/pose --once
```

Reset sends a stop, disables the pen, calls turtlesim's teleport_absolute and clear services,
confirms return to (5.544445, 5.544445, 0), and restores the pen. No teleport line should appear.
It returns failure during active motion; finish/cancel the goal first. Repeat reset twice to test it.

### Square action

```bash
ros2 action send_goal /draw_square turtle_interfaces/action/DrawSquare '{side_length: 2.0}' --feedback
```

The square action resets first, then sends exactly four separate sequential pose goals:

| Side | Target x | Target y | Final yaw |
| --- | --- | --- | --- |
| 1 | start_x + L | start_y | pi/2 |
| 2 | start_x + L | start_y + L | pi |
| 3 | start_x | start_y + L | -pi/2 |
| 4 | start_x | start_y | 0 |

Valid L: 0.1 to 5.0. Each corner turns in place. Feedback lists sides 1,2,3,4.
Controller logs show four accepted goToPose goals per successful square.
Run twice to verify reset at each start. Do not send external pose/reset/teleop commands between edges.

### Cancel an action

```bash
ros2 service call /go_to_pose/_action/cancel_goal action_msgs/srv/CancelGoal '{}'
ros2 service call /draw_square/_action/cancel_goal action_msgs/srv/CancelGoal '{}'
```

An all-zero CancelGoal request cancels all goals on that action. Square cancellation propagates to its active child.
Cancel only the action you intend to stop; wait for cancellation before resetting or submitting another goal.

## Verification and limits

Offline checks, no ROS needed:

```bash
PYTHONPATH=turtle_control python3 -m unittest discover -s turtle_control/test -v
```

This edition has 13 tests: the original 8 controller tests, four real OS-lock lifecycle tests,
and a square edge-deviation test. The geometry test simulates the actual strategy and checks
cross-track errors at 0.8-, 2- and 5-unit squares. All 13 passed during preparation.
Python, shell, XML and JSON syntax/configuration checks passed too.

With a fresh launch at default speeds and no current action, run the real integration checks:

```bash
bash scripts/test_ros.sh
```

To run colcon's tests after building:

```bash
source scripts/workspace.sh
colcon test --packages-select turtle_control
colcon test-result --verbose
```

The current preparation environment has NO ROS installation. The updated Lyrical build,
GUI rendering, live integration tests and new recording have not been run here.
No promise is made that every future hardware, environment or runtime error is impossible.
The existing Jazzy evidence is historical, not a runtime test of this updated version.

## Design-pattern bonus

Strategy: RotateDriveStrategy encapsulates step(pose, target, max_linear, max_angular).
The motion server composes a new strategy for each action goal and owns ROS communication;
the strategy owns movement math and can be replaced independently. Its explicit enum is a
finite state machine ALIGN -> DRIVE -> FINAL -> DONE, not a separate class-based GoF State-pattern claim.
The ROS-independent interface allows the same algorithm to be tested without ROS.

## Bag bonus

The original square_demo/ SQLite bag and all evidence/ files from the uploaded project are
preserved unchanged. Its 1,883 messages are 553 Twist commands and 1,330 old turtlesim/msg/Pose samples.
The supplied historical logs report a Jazzy recording/replay. They are not relabelled as Lyrical evidence.

To record your actual Lyrical run, leave the launch open and idle:

```bash
bash scripts/record_square.sh
```

This records a new square under bags/lyrical_square_TIMESTAMP and prints its real path.
The drawing helper checks success, and the recorder closes cleanly on failure or interruption.
To inspect/replay, substitute the actual printed folder:

```bash
source scripts/workspace.sh
ros2 bag info bags/YOUR_ACTUAL_FOLDER
/usr/bin/python3 scripts/check_bag_replay.py --bag bags/YOUR_ACTUAL_FOLDER
```

The checker resets first, replays only cmd_vel, samples the live Lyrical pose, and writes
new results to evidence/lyrical_replay_trajectory.json. It does not overwrite the old Jazzy evidence.
Open-loop playback can drift slightly from the original. Do not use teleop or send goals during replay.
The historical bag can be tried with the same checker without --bag; cross-distribution replay is not verified here.

## Submission and troubleshooting

Fill in all three names/IDs. Keep the two package folders and README; include the actual bag and
honest recording/replay evidence for the bonus. Exclude build/, install/, log/ and Python caches.
Nothing is uploaded automatically. Follow the instructor's submission rules when you choose to submit.

- Already running: use the existing terminal/window, or Ctrl+C its launcher before restarting.
- Existing old nodes on domain 86: stop that old launch. The starter will not kill unrelated programs.
- Missing dependency: run bash scripts/install_dependencies.sh.
- No GUI: run from your Ubuntu desktop; unset QT_QPA_PLATFORM if it was set to offscreen.
- Wrong package selected: use scripts rather than a terminal sourced with another project.
- The square takes longer at corners: tighter tolerances deliberately finish alignment before moving.
- A warning/error remains: copy the full launch output. Do not open more launch terminals.

Primary compatibility references:
- https://index.ros.org/p/turtlesim/
- https://index.ros.org/p/rosbag2_storage_sqlite3/
- https://docs.ros.org/en/lyrical/
- https://refactoring.guru/design-patterns/strategy
