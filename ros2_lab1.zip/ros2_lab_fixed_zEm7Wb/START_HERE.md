# Start here - one command

This version is for Ubuntu 26.04 and ROS 2 Lyrical.
It includes permanent Lyrical imports, tighter drawing tolerances and duplicate-run guards.

## First use of this updated ZIP

1. Stop your previous lab launches: press Ctrl+C in their terminals.
2. Extract the NEW ZIP into a NEW folder. Do not merge it into your previous workspace.
3. Open the folder containing START_LAB.sh in VS Code (File -> Open Folder).
4. Choose Terminal -> New Terminal. Use Bash.
5. Run:

```bash
bash START_LAB.sh
```

The script builds both packages, starts one simulator and both servers, waits until
pose data and the action server are ready, then draws one square automatically.
Keep this terminal open. It should print SUCCESS: square complete using four pose goals.
Press Ctrl+C in this same terminal to stop this run and its child processes.

There is no second launch command, source command, or export command to remember.
The scripts select domain 86 consistently so they do not interact with your old domain-0 or domain-42 runs.
If you run the starter again while it is open, it refuses the second run.

## Draw another square

Wait until the first finishes. In another terminal IN THE SAME FOLDER:

```bash
bash scripts/draw_square.sh
```

This sends a goal to the existing server. It does not launch another simulator.

## Test / bag bonus

With the launch running and idle, use:

```bash
bash scripts/test_ros.sh
```

To record a NEW square for the bag bonus:

```bash
bash scripts/record_square.sh
```

The recorder prints the real new bag path and replay verification command.
Source the project in that terminal before using the printed Python command:

```bash
source scripts/workspace.sh
```

## If prerequisites are missing

You already installed these during our earlier steps. If a dependency is missing:

```bash
bash scripts/install_dependencies.sh
```

Then run bash START_LAB.sh again after installation succeeds.

## What was checked?

See VALIDATION.md. The numerical/controller and OS-lock tests run without ROS.
This preparation environment does not contain ROS, so the full Lyrical build,
GUI draw and live ROS tests still need verification on your laptop.
No software update can guarantee that every future error is impossible. The starter
handles the duplicate-launch and startup issues observed in your screenshots.
