#!/usr/bin/env python3
"""Send one square goal only after discovery and fresh pose data are ready."""
import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from action_msgs.msg import GoalStatus
from turtlesim_msgs.msg import Pose
from turtle_interfaces.action import DrawSquare


def main():
    rclpy.init()
    node=Node('lab_square_demo')
    client=ActionClient(node,DrawSquare,'/draw_square')
    pose_received=[0.0]
    node.create_subscription(Pose,'/turtle1/pose',
        lambda _:pose_received.__setitem__(0,time.monotonic()),10)
    handle=None
    result_future=None
    try:
        print('Waiting for turtlesim and the square server...',flush=True)
        deadline=time.monotonic()+30.0
        while not (client.server_is_ready() and time.monotonic()-pose_received[0]<1.0):
            if time.monotonic()>=deadline:
                raise RuntimeError('Lab is not ready. Start it once with bash START_LAB.sh.')
            rclpy.spin_once(node,timeout_sec=.1)
        # Check known server names after initial graph discovery before sending.
        for name in ('motion_server','square_server','turtlesim'):
            if node.get_node_names().count(name)>1:
                raise RuntimeError(f'Multiple {name} nodes found. Stop duplicate launches first.')
        goal=DrawSquare.Goal(side_length=2.0)
        future=client.send_goal_async(goal,feedback_callback=lambda m:
            print(f'Side {m.feedback.side}/4: {m.feedback.status}',flush=True))
        rclpy.spin_until_future_complete(node,future,timeout_sec=15.)
        if not future.done() or future.result() is None:
            raise RuntimeError('No goal response. Check the launch terminal.')
        handle=future.result()
        if not handle.accepted:
            raise RuntimeError('Square server is busy. Let the current square finish first.')
        result_future=handle.get_result_async()
        rclpy.spin_until_future_complete(node,result_future,timeout_sec=310.)
        if not result_future.done():
            raise RuntimeError('Timed out waiting for the square.')
        outcome=result_future.result()
        if outcome.status != GoalStatus.STATUS_SUCCEEDED or not outcome.result.success:
            raise RuntimeError(outcome.result.message)
        print('SUCCESS: square complete using four pose goals.',flush=True)
        return 0
    except (RuntimeError, KeyboardInterrupt) as exc:
        if handle is not None and handle.accepted and (result_future is None or not result_future.done()) and rclpy.ok():
            try:
                future=handle.cancel_goal_async()
                rclpy.spin_until_future_complete(node,future,timeout_sec=3.)
            except Exception:
                pass
        print(f'Square stopped: {exc}',flush=True)
        return 1
    finally:
        client.destroy()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__=='__main__':
    raise SystemExit(main())
