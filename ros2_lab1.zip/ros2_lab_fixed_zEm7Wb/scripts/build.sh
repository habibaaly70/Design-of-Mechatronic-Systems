#!/usr/bin/env bash
set -eo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/environment.sh"
# Package directories may live directly in the workspace, as they do in this ZIP.
colcon build --symlink-install --base-paths turtle_interfaces turtle_control
printf '\nBuild finished. Next: bash scripts/run.sh\n'
