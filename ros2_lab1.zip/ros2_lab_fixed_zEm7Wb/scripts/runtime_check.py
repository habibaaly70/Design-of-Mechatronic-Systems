#!/usr/bin/env python3
"""Run after ros2 launch turtle_control lab.launch.py. Requires real ROS 2."""
import json
import math
import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rcl_interfaces.srv import GetParameters, SetParameters
from rcl_interfaces.msg import Parameter, ParameterValue, ParameterType
from std_srvs.srv import Trigger
from turtlesim_msgs.msg import Pose
from geometry_msgs.msg import Twist
from turtle_interfaces.action import GoToPose, DrawSquare
from turtle_interfaces.srv import SetSpeedLimits

rclpy.init()
node = Node('lab_runtime_check')
pose = None
commands = []
results = []
def on_pose(msg):
    global pose
    pose = msg
node.create_subscription(Pose, '/turtle1/pose', on_pose, 10)
node.create_subscription(Twist, '/turtle1/cmd_vel', lambda m: commands.append((time.monotonic(),m.linear.x,m.angular.z)), 10)
move = ActionClient(node, GoToPose, '/go_to_pose')
square = ActionClient(node, DrawSquare, '/draw_square')
reset = node.create_client(Trigger, '/reset_turtle')
speed = node.create_client(SetSpeedLimits, '/set_speed_limits')
getparam = node.create_client(GetParameters, '/motion_server/get_parameters')
setparam = node.create_client(SetParameters, '/motion_server/set_parameters')

def spin_for(seconds):
    end = time.monotonic()+seconds
    while time.monotonic()<end:
        rclpy.spin_once(node, timeout_sec=.02)

def wait(future, seconds=60):
    end = time.monotonic()+seconds
    while not future.done():
        if time.monotonic()>end:
            raise TimeoutError('Operation timed out')
        rclpy.spin_once(node, timeout_sec=.05)
    return future.result()

def call(client, req):
    assert client.wait_for_service(timeout_sec=10), client.srv_name
    return wait(client.call_async(req),30)

def reset_ok():
    assert call(reset,Trigger.Request()).success
    spin_for(.1)
    assert math.hypot(pose.x-5.544445,pose.y-5.544445)<.04
    assert abs(pose.theta)<.03

def limits(v,w):
    req=SetSpeedLimits.Request()
    req.max_linear_speed,req.max_angular_speed=v,w
    return call(speed,req)

def target(x,y,yaw):
    goal=GoToPose.Goal()
    goal.target.x,goal.target.y,goal.target.yaw=x,y,yaw
    return goal

def pose_close(x,y,yaw):
    spin_for(.1)
    assert math.hypot(pose.x-x,pose.y-y)<.06, (pose.x,pose.y,x,y)
    assert abs(math.atan2(math.sin(pose.theta-yaw),math.cos(pose.theta-yaw)))<.04

def passed(name):
    results.append({'test':name,'status':'PASS'})
    print('PASS:',name,flush=True)

try:
    assert move.wait_for_server(timeout_sec=15)
    assert square.wait_for_server(timeout_sec=15)
    spin_for(.5)
    assert pose is not None
    reset_ok(); reset_ok()
    passed('Reset repeated; pose and yaw confirmed')

    req=GetParameters.Request(); req.names=['max_linear_speed','max_angular_speed']
    initial=call(getparam,req)
    assert [v.double_value for v in initial.values]==[1.5,2.0]
    passed('Launch YAML parameters applied')

    assert limits(1.2,1.7).success
    assert not limits(-1.0,3.0).success
    assert [v.double_value for v in call(getparam,req).values]==[1.2,1.7]
    p=Parameter(); p.name='max_linear_speed'
    p.value=ParameterValue(type=ParameterType.PARAMETER_DOUBLE,double_value=0.0)
    setreq=SetParameters.Request();setreq.parameters=[p]
    assert not call(setparam,setreq).results[0].successful
    p.value.double_value=.8
    assert call(setparam,setreq).results[0].successful
    assert call(getparam,req).values[0].double_value==.8
    passed('Custom service atomicity; direct parameter changes and invalid values')

    assert limits(1.5,2.0).success
    for xyz in [(6.5,5.54,1.57),(6.5,6.5,3.1),(5.5,6.5,-1.57),(5.5,5.5,0.0)]:
        feedback=[]
        h=wait(move.send_goal_async(target(*xyz),feedback_callback=lambda m:feedback.append(m.feedback)))
        assert h.accepted
        outcome=wait(h.get_result_async())
        assert outcome.status==4 and outcome.result.success
        assert feedback
        pose_close(*xyz)
    passed('Four directions and final yaw; feedback/results')

    bad=wait(move.send_goal_async(target(12.,5.,0.)))
    assert not bad.accepted
    passed('Out-of-window goal rejected')

    reset_ok()
    h=wait(move.send_goal_async(target(9.,5.544445,0.)))
    assert h.accepted
    spin_for(.3)
    assert not call(reset,Trigger.Request()).success
    second=wait(move.send_goal_async(target(6.,6.,0.)))
    assert not second.accepted
    assert limits(.3,.5).success
    changed=time.monotonic()
    spin_for(.6)
    recent=[(v,w) for t,v,w in commands if t>changed+.15]
    assert recent and all(abs(v)<=.30001 and abs(w)<=.50001 for v,w in recent)
    assert wait(h.cancel_goal_async()).goals_canceling
    canceled=wait(h.get_result_async(),10)
    assert canceled.status==5
    spin_for(.15)
    assert commands[-1][1:]==(0.,0.)
    passed('Live speed limits, busy rejection, pose cancellation and stop')

    assert limits(1.5,2.0).success
    reset_ok()
    for _ in range(2):
        goal=DrawSquare.Goal(); goal.side_length=.8
        feedback=[]
        h=wait(square.send_goal_async(goal,feedback_callback=lambda m:feedback.append(m.feedback.side)))
        assert h.accepted
        outcome=wait(h.get_result_async(),90)
        assert outcome.status==4 and outcome.result.success,outcome
        assert feedback==[1,2,3,4],feedback
        pose_close(5.544445,5.544445,0.)
    passed('Square repeated twice; four ordered sides; final pose')

    goal=DrawSquare.Goal();goal.side_length=2.
    h=wait(square.send_goal_async(goal)); assert h.accepted
    spin_for(.8)
    duplicate=wait(square.send_goal_async(goal)); assert not duplicate.accepted
    assert wait(h.cancel_goal_async()).goals_canceling
    canceled=wait(h.get_result_async(),15)
    assert canceled.status==5
    spin_for(.15)
    assert commands[-1][1:]==(0.,0.)
    reset_ok()
    passed('Square busy rejection, cancellation propagates, reset works afterward')

    goal.side_length=6.
    assert not wait(square.send_goal_async(goal)).accepted
    passed('Oversized square rejected')
    print(json.dumps({'passed':len(results),'results':results},indent=2),flush=True)
finally:
    node.destroy_node()
    rclpy.shutdown()
