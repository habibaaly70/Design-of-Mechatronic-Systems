#!/usr/bin/env python3
"""Build and launch one lab instance; optionally draw once without a second terminal."""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'turtle_control'))
from turtle_control.session import AlreadyRunning, ProcessLease


def stop_owned(process):
    if process is None or process.poll() is not None:
        return
    # Only signal a process group started by this runner, never unrelated ROS work.
    try:
        os.killpg(process.pid, signal.SIGINT)
        process.wait(timeout=12)
    except ProcessLookupError:
        pass
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=5)
        except ProcessLookupError:
            pass
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()


def preflight():
    import rclpy
    from rclpy.node import Node
    rclpy.init()
    node = Node('lab_startup_check')
    try:
        deadline = time.monotonic()+2.0
        while time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
        # Also catches older unguarded lab processes in this domain.
        names = node.get_node_names()
        conflicts = sorted({n for n in names if n in {'turtlesim','motion_server','square_server'}})
        if conflicts or node.count_publishers('/turtle1/pose'):
            raise RuntimeError('A turtle lab is already present on this ROS domain: '
                               + ', '.join(conflicts or ['turtle pose publisher'])
                               + '. Stop its launch with Ctrl+C before starting another.')
    finally:
        node.destroy_node()
        rclpy.shutdown()


def run_session():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--demo', action='store_true', help='Draw one square after startup')
    args=parser.parse_args()
    launcher = demo = builder = None
    try:
        preflight()
        print('Building the two packages...', flush=True)
        builder=subprocess.Popen(['bash', 'scripts/build.sh'], cwd=ROOT, start_new_session=True)
        if builder.wait() != 0:
            print('Build failed. Copy the error above; the simulator was not started.', file=sys.stderr)
            return 1
        print(f'Starting one lab on ROS domain {os.environ.get("ROS_DOMAIN_ID")}. '
              'Keep this terminal open; Ctrl+C stops this run.', flush=True)
        launcher=subprocess.Popen(['bash', '-c',
            'source "$1"; exec ros2 launch turtle_control lab.launch.py',
            'lab_launch', str(ROOT/'install/setup.bash')], cwd=ROOT, start_new_session=True)
        if args.demo:
            demo=subprocess.Popen(['bash','scripts/draw_square.sh'], cwd=ROOT, start_new_session=True)
        demo_reported = False
        while launcher.poll() is None:
            if demo is not None and demo.poll() is not None and not demo_reported:
                demo_reported=True
                if demo.returncode == 0:
                    print('Square finished. Leave the window open, or press Ctrl+C to stop.', flush=True)
                else:
                    print('The square did not finish. Copy the message above. '
                          'Do not start a second launch.', flush=True)
            time.sleep(0.1)
        return launcher.returncode or 0
    except AlreadyRunning as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print('Stopping this lab...', flush=True)
        return 0
    except (RuntimeError, OSError, ImportError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    finally:
        stop_owned(demo)
        stop_owned(launcher)
        stop_owned(builder)


def request_shutdown(signum, frame):
    # A closed terminal (SIGHUP) should not leave detached launch children behind.
    raise KeyboardInterrupt


def main():
    signal.signal(signal.SIGTERM, request_shutdown)
    signal.signal(signal.SIGHUP, request_shutdown)
    try:
        with ProcessLease('launcher'):
            return run_session()
    except AlreadyRunning as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
