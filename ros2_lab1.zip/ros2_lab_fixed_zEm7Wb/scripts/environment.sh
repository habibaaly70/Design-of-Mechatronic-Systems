#!/usr/bin/env bash
LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$LAB_ROOT"
# Use a project domain consistently in every helper, independent of inherited terminal settings.
export ROS_DOMAIN_ID="${TURTLE_LAB_DOMAIN_ID:-86}"
if [[ ! -f /opt/ros/lyrical/setup.bash ]]; then
  echo 'ROS 2 Lyrical was not found at /opt/ros/lyrical/setup.bash.' >&2
  return 1
fi
source /opt/ros/lyrical/setup.bash
