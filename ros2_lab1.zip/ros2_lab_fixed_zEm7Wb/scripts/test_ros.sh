#!/usr/bin/env bash
set -eo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/workspace.sh"
# Real ROS integration checks; leave the launch running, with no active goal/teleop.
exec /usr/bin/python3 scripts/runtime_check.py
