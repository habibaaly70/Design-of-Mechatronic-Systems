#!/usr/bin/env bash
# Source this from a Bash terminal, or let the helper scripts source it for you.
source "$(dirname "${BASH_SOURCE[0]}")/environment.sh" || return 1
if [[ ! -f "$LAB_ROOT/install/setup.bash" ]]; then
  echo 'Build first: bash scripts/build.sh' >&2
  return 1
fi
source "$LAB_ROOT/install/setup.bash"
