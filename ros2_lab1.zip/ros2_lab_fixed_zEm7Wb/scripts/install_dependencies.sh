#!/usr/bin/env bash
set -eo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/environment.sh"
sudo apt update
sudo apt install -y build-essential cmake python3-colcon-common-extensions python3-pytest python3-setuptools \
  ros-lyrical-turtlesim ros-lyrical-turtlesim-msgs ros-lyrical-rclpy \
  ros-lyrical-ament-cmake ros-lyrical-rosidl-default-generators \
  ros-lyrical-geometry-msgs ros-lyrical-std-srvs ros-lyrical-rcl-interfaces \
  ros-lyrical-action-msgs ros-lyrical-launch-ros ros-lyrical-ament-index-python \
  ros-lyrical-ros2bag ros-lyrical-rosbag2-storage-sqlite3
printf '\nDependencies installed. Next: bash scripts/build.sh\n'
