#!/usr/bin/env bash
set -eo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/workspace.sh"
exec /usr/bin/python3 scripts/send_square.py
