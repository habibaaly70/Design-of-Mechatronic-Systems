# Jazzy / Ubuntu 24.04 adaptation

Changed all live Python imports from turtlesim_msgs to turtlesim, adjusted package.xml and apt dependencies, and changed setup scripts to source /opt/ros/jazzy/setup.bash.
Removed uploaded build/, install/, log/ and Python caches; these contained machine-specific Python 3.14 binaries and must be rebuilt on Ubuntu 24.04.
Retained the drawing precision, duplicate-run guards and original evidence/bag files. Build is scoped to the two source packages. Paths with spaces or parentheses are rejected with relocation instructions before CMake runs. An already-sourced different ROS distribution is rejected.

Validation of this revision: all 13 offline tests passed; Python 3.12 grammar, Bash syntax and package XML checks passed. No ROS installation is available here, so a real Jazzy colcon build, simulator launch and live integration tests have NOT been run for this revision. Run bash START_LAB.sh, then bash scripts/test_ros.sh in a second terminal while the simulator is idle.

VALIDATION_PREVIOUS.md contains the supplied historical claims, not results obtained for this revision.
