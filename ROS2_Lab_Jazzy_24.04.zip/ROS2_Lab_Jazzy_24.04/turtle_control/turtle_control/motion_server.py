import math
import threading
import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer, GoalResponse, CancelResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.parameter import Parameter
from rcl_interfaces.msg import SetParametersResult
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import TeleportAbsolute, SetPen
from std_srvs.srv import Empty, Trigger
from turtle_interfaces.action import GoToPose
from turtle_interfaces.srv import SetSpeedLimits
from .controller import START, Phase, RotateDriveStrategy, valid_target, valid_speeds
from .common import run, wait_future

class MotionServer(Node):
    def __init__(self):
        super().__init__('motion_server')
        self.group = ReentrantCallbackGroup()
        self.motion_lock = threading.Lock()
        self.pose_lock = threading.Lock()
        self.latest_pose = None
        self.pose_time = 0.0
        self.declare_parameter('max_linear_speed', 1.5)
        self.declare_parameter('max_angular_speed', 2.0)
        if not valid_speeds(*self.speeds()):
            raise ValueError('Initial speed limits must be finite and positive')
        self.add_on_set_parameters_callback(self.validate_parameters)
        self.pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.sub = self.create_subscription(Pose, '/turtle1/pose', self.on_pose, 10,
                                            callback_group=self.group)
        self.clear_client = self.create_client(Empty, '/clear', callback_group=self.group)
        self.teleport_client = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute', callback_group=self.group)
        self.pen_client = self.create_client(SetPen, '/turtle1/set_pen', callback_group=self.group)
        self.reset_service = self.create_service(Trigger, '/reset_turtle', self.reset, callback_group=self.group)
        self.speed_service = self.create_service(SetSpeedLimits, '/set_speed_limits', self.set_speeds, callback_group=self.group)
        self.action = ActionServer(self, GoToPose, '/go_to_pose', self.execute,
            goal_callback=self.goal, cancel_callback=lambda _: CancelResponse.ACCEPT,
            callback_group=self.group)

    def speeds(self):
        return (self.get_parameter('max_linear_speed').value,
                self.get_parameter('max_angular_speed').value)

    def validate_parameters(self, parameters):
        for p in parameters:
            if p.name in ('max_linear_speed', 'max_angular_speed'):
                if p.type_ != Parameter.Type.DOUBLE or not math.isfinite(p.value) or p.value <= 0:
                    return SetParametersResult(successful=False, reason='Speed limits must be finite positive doubles')
        return SetParametersResult(successful=True)

    def set_speeds(self, request, response):
        result = self.set_parameters_atomically([
            Parameter('max_linear_speed', value=request.max_linear_speed),
            Parameter('max_angular_speed', value=request.max_angular_speed)])
        response.success = result.successful
        response.message = 'Speed limits updated' if result.successful else result.reason
        return response

    def on_pose(self, msg):
        with self.pose_lock:
            self.latest_pose = (msg.x, msg.y, msg.theta)
            self.pose_time = time.monotonic()

    def pose_snapshot(self):
        with self.pose_lock:
            return self.latest_pose, self.pose_time

    def stop(self):
        self.pub.publish(Twist())

    def goal(self, request):
        target = request.target
        pose, stamp = self.pose_snapshot()
        if (not valid_target((target.x, target.y, target.yaw)) or pose is None
                or time.monotonic()-stamp > 2.0):
            return GoalResponse.REJECT
        # Reserve before accepting, so competing goals/reset cannot race.
        return GoalResponse.ACCEPT if self.motion_lock.acquire(blocking=False) else GoalResponse.REJECT

    def execute(self, handle):
        result = GoToPose.Result()
        t = handle.request.target
        target = (t.x, t.y, t.yaw)
        strategy = RotateDriveStrategy()
        deadline = time.monotonic() + 300.0
        last_feedback = 0.0
        self.get_logger().info(f'goToPose accepted: {target}')
        try:
            while rclpy.ok():
                if handle.is_cancel_requested:
                    handle.canceled()
                    result.message = 'Canceled'
                    return result
                if time.monotonic() > deadline:
                    raise TimeoutError('Goal exceeded 300 seconds; increase speed and retry')
                pose, stamp = self.pose_snapshot()
                if pose is None or time.monotonic()-stamp > 2.0:
                    raise RuntimeError('Pose data is stale; check turtlesim')
                v, w, distance, angle = strategy.step(pose, target, *self.speeds())
                cmd = Twist()
                cmd.linear.x, cmd.angular.z = float(v), float(w)
                self.pub.publish(cmd)
                if time.monotonic()-last_feedback >= 0.1:
                    feedback = GoToPose.Feedback()
                    feedback.distance_remaining, feedback.angle_error = distance, angle
                    feedback.phase = strategy.phase.value
                    handle.publish_feedback(feedback)
                    last_feedback = time.monotonic()
                if strategy.phase == Phase.DONE:
                    handle.succeed()
                    result.success, result.message = True, 'Target pose reached'
                    return result
                time.sleep(0.02)
            result.message = 'ROS shutdown'
        except Exception as exc:
            result.message = str(exc)
            self.get_logger().error(str(exc))
        finally:
            if rclpy.ok():
                self.stop()
            self.motion_lock.release()
        if handle.is_active:
            handle.abort()
        return result

    def call(self, client, request):
        if not client.wait_for_service(timeout_sec=5.0):
            raise TimeoutError(f'Service unavailable: {client.srv_name}')
        return wait_future(client.call_async(request))

    def pen(self, off):
        request = SetPen.Request()
        request.r, request.g, request.b = 179, 184, 255
        request.width, request.off = 3, int(off)
        self.call(self.pen_client, request)

    def reset(self, request, response):
        if not self.motion_lock.acquire(blocking=False):
            response.success, response.message = False, 'Motion/reset busy; wait or cancel the active goal'
            return response
        pen_disabled = False
        try:
            self.stop()
            self.pen(True)
            pen_disabled = True
            target = TeleportAbsolute.Request()
            target.x, target.y, target.theta = START
            self.call(self.teleport_client, target)
            # Clear after teleport as well, ensuring a clean screen.
            self.call(self.clear_client, Empty.Request())
            deadline = time.monotonic()+2.0
            while True:
                pose, _ = self.pose_snapshot()
                if pose is not None and math.hypot(pose[0]-START[0], pose[1]-START[1]) < 0.02 and abs(pose[2]) < 0.02:
                    break
                if time.monotonic() > deadline:
                    raise TimeoutError('Reset pose confirmation timed out')
                time.sleep(0.02)
            self.pen(False)
            pen_disabled = False
            response.success, response.message = True, 'Drawing cleared; turtle returned to start'
        except Exception as exc:
            response.success, response.message = False, str(exc)
        finally:
            if pen_disabled and rclpy.ok():
                try:
                    self.pen(False)
                except Exception:
                    self.get_logger().error('Could not restore pen; check turtlesim')
            self.motion_lock.release()
        return response

def main(args=None):
    run(MotionServer, args)
