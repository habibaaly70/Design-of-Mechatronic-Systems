#!/usr/bin/env bash
set -eo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/environment.sh"
if [[ "$LAB_ROOT" =~ [[:space:]\(\)] ]]; then
  echo 'Move this extracted folder to ~/ROS2_Lab_Jazzy_24.04 (no spaces or parentheses in its path), then retry.' >&2
  exit 1
fi
# Package directories may live directly in the workspace, as they do in this ZIP.
colcon build --symlink-install --base-paths turtle_interfaces turtle_control --cmake-args -DPython3_EXECUTABLE=/usr/bin/python3
printf '\nBuild finished. Next: bash scripts/run.sh\n'
