#!/usr/bin/env bash
# Launch the lab first, wait until idle, then run this in a second terminal.
set -eo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/workspace.sh"
mkdir -p bags
bag_path="bags/jazzy_square_$(date +%Y%m%d_%H%M%S)"
recorder_pid=''
cleanup() {
  if [[ -n "$recorder_pid" ]]; then
    kill -INT "$recorder_pid" 2>/dev/null || true
    wait "$recorder_pid" || true
    recorder_pid=''
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
ros2 bag record -s sqlite3 -o "$bag_path" /turtle1/cmd_vel /turtle1/pose &
recorder_pid=$!
ready=false
for attempt in {1..30}; do
  if ros2 node list | grep -q '^/rosbag2_recorder$'; then ready=true; break; fi
  if ! kill -0 "$recorder_pid" 2>/dev/null; then echo 'Recorder exited'; exit 1; fi
  sleep 0.2
done
if [[ "$ready" != true ]]; then echo 'Recorder did not start'; exit 1; fi
sleep 1
# The action itself resets the screen before drawing.
bash scripts/draw_square.sh
sleep 1
cleanup
ros2 bag info "$bag_path"
printf '\nCheck that the square result said success: true.\nRecording: %s\n' "$bag_path"
printf 'To verify replay, run: /usr/bin/python3 scripts/check_bag_replay.py --bag %q\n' "$bag_path"
