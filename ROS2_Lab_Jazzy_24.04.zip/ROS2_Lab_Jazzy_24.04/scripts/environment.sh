#!/usr/bin/env bash
LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$LAB_ROOT"
# Use a project domain consistently in every helper, independent of inherited terminal settings.
export ROS_DOMAIN_ID="${TURTLE_LAB_DOMAIN_ID:-86}"
if [[ ! -f /opt/ros/jazzy/setup.bash ]]; then
  echo 'ROS 2 Jazzy was not found at /opt/ros/jazzy/setup.bash.' >&2
  return 1
fi
if [[ -n "${ROS_DISTRO:-}" && "$ROS_DISTRO" != jazzy ]]; then
  echo "Another ROS distribution ($ROS_DISTRO) is sourced. Open a clean Bash terminal with only Jazzy sourced." >&2
  return 1
fi
# Use Ubuntu's Python and tools rather than an active Conda/venv installation.
export PATH="/usr/bin:/bin:$PATH"
source /opt/ros/jazzy/setup.bash
