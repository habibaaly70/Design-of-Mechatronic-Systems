#!/usr/bin/env python3
"""Replay the included bag against a running, idle lab launch; verify live poses."""
import argparse, json, math, subprocess, time
from pathlib import Path
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from std_srvs.srv import Trigger
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--bag', type=Path, default=root/'square_demo',
                    help='Bag directory; defaults to the included historical Jazzy recording')
args=parser.parse_args()
if not args.bag.is_dir():
    parser.error('Bag directory does not exist')
rclpy.init()
node=Node('bag_replay_check')
points=[]
node.create_subscription(Pose,'/turtle1/pose',lambda p:points.append([time.time(),p.x,p.y,p.theta]),10)
client=node.create_client(Trigger,'/reset_turtle')
player=None
try:
    assert client.wait_for_service(timeout_sec=15)
    f=client.call_async(Trigger.Request())
    rclpy.spin_until_future_complete(node,f,timeout_sec=20)
    assert f.done() and f.result().success
    deadline=time.monotonic()+.3
    while time.monotonic()<deadline:rclpy.spin_once(node,timeout_sec=.02)
    points.clear()
    player=subprocess.Popen(['ros2','bag','play',str(args.bag.resolve()),'--topics','/turtle1/cmd_vel'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    deadline=time.monotonic()+60
    while player.poll() is None:
        if time.monotonic()>deadline:raise TimeoutError('Replay timed out')
        rclpy.spin_once(node,timeout_sec=.02)
    assert player.returncode==0
    for _ in range(10):rclpy.spin_once(node,timeout_sec=.02)
    assert len(points)>100
    x0=y0=5.544445
    corners=[(x0+2,y0),(x0+2,y0+2),(x0,y0+2),(x0,y0)]
    nearest=[min(math.hypot(p[1]-x,p[2]-y) for p in points) for x,y in corners]
    final=math.hypot(points[-1][1]-x0,points[-1][2]-y0)
    result={'samples':len(points),'corner_min_distances':nearest,'final_position_error':final,'final_yaw':points[-1][3]}
    assert max(nearest)<.15,result
    assert final<.15,result
    assert abs(points[-1][3])<.08,result
    (root/'evidence/jazzy_replay_trajectory.json').write_text(json.dumps({'poses':points,'result':result}))
    print(json.dumps(result,indent=2))
    print('PASS: actual replay visits all four corners and returns near start')
finally:
    if player is not None and player.poll() is None:player.terminate();player.wait()
    node.destroy_node();rclpy.shutdown()
