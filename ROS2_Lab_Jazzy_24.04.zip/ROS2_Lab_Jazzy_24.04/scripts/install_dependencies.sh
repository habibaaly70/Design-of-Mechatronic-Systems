#!/usr/bin/env bash
set -eo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/environment.sh"
sudo apt update
sudo apt install -y build-essential cmake python3-colcon-common-extensions python3-pytest python3-setuptools \
  ros-jazzy-turtlesim ros-jazzy-rclpy \
  ros-jazzy-ament-cmake ros-jazzy-rosidl-default-generators \
  ros-jazzy-geometry-msgs ros-jazzy-std-srvs ros-jazzy-rcl-interfaces \
  ros-jazzy-action-msgs ros-jazzy-launch-ros ros-jazzy-ament-index-python \
  ros-jazzy-ros2bag ros-jazzy-rosbag2-storage-sqlite3
printf '\nDependencies installed. Next: bash scripts/build.sh\n'
